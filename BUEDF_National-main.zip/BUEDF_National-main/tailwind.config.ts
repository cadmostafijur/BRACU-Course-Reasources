import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        midnight: "#070B1F",
        twilight: "#0E1E38",
        deepSea: "#152C52",
        sapphire: "#1F3D7A",
        auroraBlue: "#4CC2FF",
        aquaGlow: "#2AF6C1",
        goldenRay: "#F6C77F",
        mist: "#E7ECFC",
        silver: "#c0c6d9"
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
        display: ["'Bebas Neue'", "'Oswald'", "sans-serif"]
      },
      backgroundImage: {
        "texture-dark": "url('/backgrounds/deep-texture.jpg')"
      },
      boxShadow: {
        panel: "0 30px 60px rgba(6, 11, 26, 0.55)",
        glow: "0 15px 45px rgba(76, 194, 255, 0.25)"
      },
      borderRadius: {
        pill: "9999px"
      },
      keyframes: {
        "beam-sweep": {
          "0%": { transform: "translate(-60vw, -50%) rotate(8deg)" },
          "50%": { transform: "translate(-10vw, -52%) rotate(6deg)" },
          "100%": { transform: "translate(40vw, -48%) rotate(4deg)" }
        },
        "beam-sweep-delayed": {
          "0%": { transform: "translate(-55vw, -50%) rotate(14deg)" },
          "50%": { transform: "translate(-5vw, -48%) rotate(8deg)" },
          "100%": { transform: "translate(45vw, -46%) rotate(6deg)" }
        }
      },
      animation: {
        beam: "beam-sweep 18s ease-in-out infinite",
        "beam-delayed": "beam-sweep-delayed 22s ease-in-out infinite"
      }
    }
  },
  plugins: []
};

export default config;
