import Header from "@/components/Header";
import FAQ from "@/components/FAQ";
import Footer from "@/components/Footer";

export default function FAQPage() {
  return (
    <>
      <Header />
      <div className="mx-auto max-w-5xl px-6 pt-36 pb-24">
        <FAQ fullPage />
      </div>
      <Footer compact />
    </>
  );
}

