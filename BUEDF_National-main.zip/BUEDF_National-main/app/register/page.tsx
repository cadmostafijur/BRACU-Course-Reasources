import Header from "@/components/Header";
import RegistrationForm from "@/components/RegistrationForm";
import Footer from "@/components/Footer";

export default function RegisterPage() {
  return (
    <>
      <Header />
      <div className="mx-auto max-w-4xl px-6 pt-36 pb-24">
        <RegistrationForm compact />
      </div>
      <Footer compact />
    </>
  );
}

