import "./globals.css";
import type { Metadata } from "next";
import MovingLightBackground from "@/components/MovingLightBackground";
import { Analytics } from "@vercel/analytics/next";

export const metadata: Metadata = {
  title: "KBEC Nexus Season 2",
  description: "KBEC Nexus Season 2 Business Case Competition"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="relative min-h-screen">
        <MovingLightBackground />
        {children}
        <Analytics />
      </body>
    </html>
  );
}
