import Header from "@/components/Header";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Timeline from "@/components/Timeline";
import PrizePool from "@/components/PrizePool";
import RegistrationForm from "@/components/RegistrationForm";
import FAQ from "@/components/FAQ";
import Sponsors from "@/components/Sponsors";
import Footer from "@/components/Footer";

export default function HomePage() {
  return (
    <div className="relative overflow-hidden">
      <Header />
      <main className="mx-auto flex max-w-6xl flex-col gap-24 px-6 pb-32 pt-32">
        <Hero />
        <About />
        <Timeline />
        <PrizePool />
        <RegistrationForm />
        <FAQ />
        <Sponsors />
      </main>
      <Footer />
      <button className="fixed bottom-8 right-8 rounded-full bg-gradient-to-br from-auroraBlue via-aquaGlow to-auroraBlue px-6 py-3 text-sm font-semibold uppercase tracking-[0.18em] text-midnight shadow-lg shadow-panel transition hover:scale-105">
        Support
      </button>
    </div>
  );
}
