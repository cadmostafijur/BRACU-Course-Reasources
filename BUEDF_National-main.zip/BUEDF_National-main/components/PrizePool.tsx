import Image from "next/image";

export default function PrizePool() {
  return (
    <section id="prizes" className="section-block px-8 py-16 text-center">
      <h2 className="section-title">Prize Pool</h2>
      <p className="section-subtitle mt-4">
        Premium rewards for top teams, captured at a glance.
      </p>
      <div className="mt-12 flex justify-center">
        <div className="relative w-full max-w-3xl overflow-hidden rounded-3xl border border-auroraBlue/20 bg-transparent backdrop-blur-sm p-4 shadow-panel">
          <Image
            src="/trophies/trophy-DNryeqgo.webp"
            alt="Prize pool details"
            width={1200}
            height={800}
            className="h-full w-full rounded-2xl object-cover"
            priority
          />
        </div>
      </div>
    </section>
  );
}

