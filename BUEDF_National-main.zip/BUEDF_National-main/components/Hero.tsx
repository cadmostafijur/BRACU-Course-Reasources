export default function Hero() {
  return (
    <section id="hero" className="section-block relative overflow-hidden px-8 py-16 text-center">
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-auroraBlue/20 via-transparent to-transparent opacity-60" />
      <div className="flex flex-col items-center gap-6">
        <div className="flex flex-wrap items-center justify-center gap-6 text-mist/70 text-xs uppercase tracking-[0.35em]">
          <span>BRAC University</span>
          <span className="h-3 w-px bg-mist/20" />
          <span>Entrepreneurship Development Forum (BUEDF)</span>
        </div>
        <p className="rounded-pill border border-auroraBlue/40 bg-auroraBlue/10 px-6 py-2 text-xs uppercase tracking-[0.4em] text-auroraBlue">
          Season 2
        </p>
        <h1 className="font-display text-6xl uppercase tracking-[0.22em] bg-gradient-to-r from-mist via-goldenRay to-auroraBlue bg-clip-text text-transparent drop-shadow-[0_10px_35px_rgba(76,194,255,0.35)] sm:text-7xl">
          KBEC <span className="text-transparent bg-gradient-to-r from-goldenRay to-auroraBlue bg-clip-text">Nexus</span>
        </h1>
        <p className="mx-auto max-w-3xl text-lg text-mist/80">
          A national business case competition forging the next generation of strategic thinkers. Stand out, pitch bold ideas, and compete for the ultimate bragging rights.
        </p>
        <div className="mt-10 flex flex-wrap justify-center gap-6">
          <HeroCard
            title="Prize Money"
            highlight="BDT 200K"
            description="Champion team secures cash prizes and exclusive opportunities."
          />
          <HeroCard
            title="Kickoff"
            highlight="Jan 15, 2026"
            description="Registration closes on Jan 05. Limited seats available."
          />
          <HeroCard
            title="Team Size"
            highlight="3-4"
            description="Open to all undergraduate students of BRAC University."
          />
        </div>
      </div>
    </section>
  );
}

function HeroCard({ title, highlight, description }: { title: string; highlight: string; description: string }) {
  return (
    <div className="w-full max-w-xs rounded-2xl border border-auroraBlue/15 bg-transparent backdrop-blur-sm p-6 text-left shadow-panel">
      <p className="text-xs uppercase tracking-[0.35em] text-mist/60">{title}</p>
      <h3 className="mt-2 font-display text-4xl tracking-[0.2em] text-transparent bg-gradient-to-r from-goldenRay to-auroraBlue bg-clip-text">
        {highlight}
      </h3>
      <p className="mt-3 text-sm text-mist/70">{description}</p>
    </div>
  );
}

