"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import clsx from "clsx";

const navItems = [
  { label: "About", href: "#about" },
  { label: "Timeline", href: "#timeline" },
  { label: "Prizes", href: "#prizes" },
  { label: "Sponsors", href: "#sponsors" },
  { label: "Register", href: "#register" },
  { label: "FAQ", href: "#faq" },
  { label: "Contact", href: "#contact" }
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    handler();
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <header
      className={clsx(
        "fixed inset-x-0 top-0 z-40 transition-all",
        scrolled ? "bg-midnight/85 backdrop-blur-xl border-b border-mist/10 shadow-panel" : "bg-transparent"
      )}
    >
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-4">
          <Image src="/logos/BUEDF.jpg" alt="BUEDF" width={72} height={72} className="h-16 w-16 rounded-full object-cover" />
        </Link>
        <nav className="hidden items-center gap-6 text-xs uppercase tracking-[0.25em] text-mist/70 md:flex">
          {navItems.map((item) => (
            <a key={item.href} href={item.href} className="transition hover:text-auroraBlue">
              {item.label}
            </a>
          ))}
        </nav>
        <Link href="/register" className="primary-button hidden md:inline-flex">
          Register Now
        </Link>
      </div>
    </header>
  );
}

