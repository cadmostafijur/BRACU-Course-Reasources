export default function Timeline() {
  return (
    <section id="timeline" className="section-block px-8 py-16 text-center">
      <h2 className="section-title">Competition Journey</h2>
      <p className="section-subtitle mt-4">
        Navigate four intense stages culminating in a live grand finale.
      </p>
      <div className="mt-12 flex flex-col items-center">
        <div className="relative flex w-full max-w-3xl flex-col items-center gap-12">
          {timelineSteps.map((step, index) => (
            <TimelineStep key={step.title} {...step} isLast={index === timelineSteps.length - 1} />
          ))}
        </div>
      </div>
    </section>
  );
}

function TimelineStep({
  title,
  date,
  detail,
  isLast
}: {
  title: string;
  date: string;
  detail: string;
  isLast: boolean;
}) {
  return (
    <div className="flex w-full flex-col items-center gap-6 md:flex-row md:gap-10">
      <div className="timeline-dot">{title.slice(0, 1)}</div>
      <div className="relative flex-1">
        <div className="timeline-card">
          <p className="text-xs uppercase tracking-[0.35em] text-mist/60">{date}</p>
          <h3 className="mt-2 font-display text-3xl uppercase tracking-[0.18em] text-mist">{title}</h3>
          <p className="mt-3 text-sm text-mist/70">{detail}</p>
        </div>
        {!isLast && (
          <div className="absolute left-1/2 top-full hidden h-16 -translate-x-1/2 md:block">
            <ArrowConnector />
          </div>
        )}
      </div>
      {!isLast && <div className="mt-6 h-14 w-0.5 bg-gradient-to-b from-auroraBlue/50 to-transparent md:hidden" />}
    </div>
  );
}

function ArrowConnector() {
  return (
    <div className="flex h-16 w-px flex-col items-center justify-between">
      <div className="h-10 w-px bg-gradient-to-b from-auroraBlue/60 to-transparent" />
      <div className="aspect-[5/3] w-6 origin-bottom -rotate-90 rounded-sm bg-gradient-to-br from-auroraBlue/70 to-aquaGlow/30 shadow-md" />
    </div>
  );
}

const timelineSteps = [
  {
    title: "Registration",
    date: "Dec 01 – Jan 05",
    detail: "Submit team details & payment confirmation. Limited slots; early-bird perks for the first 50 teams."
  },
  {
    title: "Round 1",
    date: "Jan 12 – Jan 19",
    detail: "Preliminary case release with 7-day submission window reviewed by corporate mentors."
  },
  {
    title: "Round 2",
    date: "Jan 26 – Feb 05",
    detail: "Top 30 teams advance to live pitch battle with Q&A from expert judges."
  },
  {
    title: "Grand Finale",
    date: "Feb 15",
    detail: "Top 10 final showdown at BRAC University auditorium broadcasted live."
  }
];

