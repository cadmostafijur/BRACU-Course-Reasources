import Image from "next/image";

export default function About() {
  return (
    <section id="about" className="section-block grid gap-10 px-8 py-16 lg:grid-cols-[1.2fr_0.8fr]">
      <div className="flex flex-col gap-6">
        <h2 className="section-title">About KBEC</h2>
        <p className="section-subtitle">
          KBEC Nexus is BRAC University Entrepreneurship Development Forum&apos;s flagship business case competition nurturing future corporate leaders. Over three power-packed rounds, teams decode real-world challenges from top industry partners, ideate strategic solutions, and present to distinguished judges.
        </p>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {whyList.map((item) => (
            <div key={item.title} className="rounded-2xl border border-auroraBlue/15 bg-transparent backdrop-blur-sm p-6 shadow-panel">
              <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-full bg-auroraBlue/15 text-auroraBlue">
                {item.icon}
              </div>
              <h3 className="font-semibold uppercase tracking-[0.25em] text-mist">{item.title}</h3>
              <p className="mt-3 text-sm text-mist/70">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="flex flex-col items-center justify-center gap-6 text-center">
        <div className="relative h-48 w-48 overflow-hidden rounded-full border-4 border-auroraBlue/40 bg-transparent backdrop-blur-sm p-6 shadow-glow">
          <Image src="/logos/BUEDF.jpg" alt="BUEDF Logo" fill className="object-contain" />
        </div>
        <p className="text-sm uppercase tracking-[0.35em] text-mist/60">Est. 2012</p>
        <p className="text-sm text-mist/70">
          Powered by BRAC University Entrepreneurship Development Forum (BUEDF), driven by innovation, and supported by strategic partners forging the brightest minds.
        </p>
      </div>
    </section>
  );
}

const whyList = [
  {
    title: "Corporate Exposure",
    description: "Pitch to CXOs, industry pioneers, and hiring partners backing the competition.",
    icon: "🏆"
  },
  {
    title: "Leadership",
    description: "Sharpen analytical skills, storytelling, and cross-functional collaboration under pressure.",
    icon: "🚀"
  },
  {
    title: "Networking",
    description: "Build alliances with like-minded innovators, alumni mentors, and venture collaborators.",
    icon: "🤝"
  },
  {
    title: "Exclusive Perks",
    description: "Access masterclasses, corporate mentoring, and fast-track recruitment opportunities.",
    icon: "🎓"
  }
];

