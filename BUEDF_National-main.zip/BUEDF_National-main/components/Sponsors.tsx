import Image from "next/image";

const sponsors = ["/logos/BUEDF.jpg", "/logos/bracu.png"];

const partners = ["/logos/BUEDF.jpg", "/logos/bracu.png", "/logos/BUEDF.jpg"];

export default function Sponsors() {
  return (
    <section id="sponsors" className="section-block px-8 py-16 text-center">
      <h2 className="section-title">Sponsors</h2>
      <div className="mt-10 grid justify-center gap-6 sm:grid-cols-3">
        {sponsors.map((logo, idx) => (
          <SponsorCard key={idx} src={logo} />
        ))}
      </div>
      <h3 className="mt-16 font-display text-3xl uppercase tracking-[0.2em] text-mist">Partners</h3>
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {partners.map((logo, idx) => (
          <SponsorCard key={`partner-${idx}`} src={logo} />
        ))}
      </div>
    </section>
  );
}

function SponsorCard({ src }: { src: string }) {
  return (
    <div className="flex items-center justify-center rounded-3xl border border-auroraBlue/15 bg-transparent backdrop-blur-sm p-8 shadow-panel">
      <div className="relative h-20 w-40">
        <Image src={src} alt="Partner logo" fill className="object-contain" />
      </div>
    </div>
  );
}

