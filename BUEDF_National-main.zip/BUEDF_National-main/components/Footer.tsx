import Image from "next/image";
import Link from "next/link";
import clsx from "clsx";

type Props = {
  compact?: boolean;
};

export default function Footer({ compact }: Props) {
  return (
    <footer id="contact" className={clsx("bg-transparent border-t border-mist/10 backdrop-blur-sm", compact ? "mt-16" : "mt-32")}>
      <div className="mx-auto flex max-w-6xl flex-col gap-10 px-6 py-16 md:flex-row md:justify-between">
        <div className="flex flex-col gap-4 text-sm text-mist/70 md:max-w-sm">
          <div className="flex items-center gap-4">
            <Image src="/logos/BUEDF.jpg" alt="KBEC" width={64} height={64} className="h-16 w-auto rounded-full object-cover shadow-glow" />
            <div>
              <p className="font-display text-2xl uppercase tracking-[0.2em] text-mist">KBEC Nexus</p>
              <p className="text-xs uppercase tracking-[0.3em] text-auroraBlue">Season 2</p>
            </div>
          </div>
          <p>BRAC University Entrepreneurship Development Forum (BUEDF), UB01 Level 13, BRAC University, 66 Mohakhali, Dhaka 1212.</p>
          <p>
            Email:{" "}
            <Link href="mailto:club.buedf@g.bracu.ac.bd" className="text-auroraBlue hover:underline">
              club.buedf@g.bracu.ac.bd
            </Link>
          </p>
          <p>Hotline: 01797-837210</p>
        </div>
        <div className="flex flex-col gap-6 text-sm text-mist/70">
          <p className="text-xs uppercase tracking-[0.3em] text-mist/60">Quick Links</p>
          <div className="flex flex-col gap-3">
            <Link href="#about" className="transition hover:text-auroraBlue">
              About Competition
            </Link>
            <Link href="#timeline" className="transition hover:text-auroraBlue">
              Competition Journey
            </Link>
            <Link href="#register" className="transition hover:text-auroraBlue">
              Apply Now
            </Link>
            <Link href="/faq" className="transition hover:text-auroraBlue">
              FAQ
            </Link>
          </div>
        </div>
        <div className="flex flex-col gap-6 text-sm text-mist/70">
          <p className="text-xs uppercase tracking-[0.3em] text-mist/60">Follow us</p>
          <div className="flex items-center gap-4">
            <SocialIcon label="Facebook" />
            <SocialIcon label="Instagram" />
            <SocialIcon label="LinkedIn" />
            <SocialIcon label="YouTube" />
          </div>
          <p className="text-xs uppercase tracking-[0.3em] text-mist/50">
            © {new Date().getFullYear()} KBEC Nexus. Crafted by BUEDF.
          </p>
        </div>
      </div>
    </footer>
  );
}

function SocialIcon({ label }: { label: string }) {
  return (
    <button className="flex h-12 w-12 items-center justify-center rounded-full border border-auroraBlue/25 bg-transparent backdrop-blur-sm text-mist/70 transition hover:border-auroraBlue hover:text-auroraBlue hover:shadow-glow">
      {label.slice(0, 1)}
    </button>
  );
}

