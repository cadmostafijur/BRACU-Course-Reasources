"use client";

import { useState } from "react";
import clsx from "clsx";

const questions = [
  {
    q: "Who can apply?",
    a: "All BRAC University undergraduate students from any department are eligible. Alumni may participate as mentors only."
  },
  {
    q: "Can I join without a team?",
    a: "Solo applicants can register interest; we will connect you with other solo participants to form a complete team."
  },
  {
    q: "What is the team size?",
    a: "Minimum 3, maximum 4 members per team. Each member must be currently enrolled at BRACU."
  },
  {
    q: "What documents are needed?",
    a: "Valid BRACU ID, payment confirmation screenshot, and student email for each member."
  },
  {
    q: "Is the registration fee refundable?",
    a: "Fees are non-refundable after payment unless the event is cancelled by organizers."
  },
  {
    q: "How are teams shortlisted?",
    a: "Round 1 submissions are evaluated by expert mentors. Top teams are invited based on strategic depth and feasibility."
  },
  {
    q: "Will there be mentoring sessions?",
    a: "Yes, shortlisted teams get access to mentorship clinics with industry professionals."
  }
];

type Props = {
  fullPage?: boolean;
};

export default function FAQ({ fullPage }: Props) {
  const [active, setActive] = useState(0);

  return (
    <section id="faq" className={clsx("section-block px-6 py-16", fullPage ? "mt-0" : "")}>
      <div className="mx-auto max-w-4xl">
        {!fullPage && <h2 className="section-title text-center">FAQ</h2>}
        <div className="mt-10 divide-y divide-mist/10">
          {questions.map((item, index) => (
            <details
              key={item.q}
              className="group"
              open={active === index}
              onClick={(event) => {
                event.preventDefault();
                setActive((prev) => (prev === index ? -1 : index));
              }}
            >
              <summary className="flex cursor-pointer items-center justify-between py-5 text-left text-lg font-semibold text-mist transition group-open:text-auroraBlue">
                <span>{item.q}</span>
                <span className="text-2xl leading-none text-auroraBlue transition group-open:rotate-45">+</span>
              </summary>
              <p className="pb-6 text-sm text-mist/70">{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

