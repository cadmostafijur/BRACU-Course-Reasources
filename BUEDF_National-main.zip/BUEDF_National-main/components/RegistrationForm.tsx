"use client";

import { type ChangeEvent, type DragEvent, useRef, useState } from "react";
import clsx from "clsx";

type Props = {
  compact?: boolean;
};

export default function RegistrationForm({ compact }: Props) {
  const [paymentMethod, setPaymentMethod] = useState<"bkash" | "nagad">("bkash");
  const [memberCount, setMemberCount] = useState(1);
  const [paymentProof, setPaymentProof] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    setPaymentProof(file ?? null);
  };

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const file = event.dataTransfer.files?.[0];
    if (file) {
      setPaymentProof(file);
    }
  };

  const handleDragOver = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  return (
    <section id="register" className={clsx("section-block px-8 py-16", { "mt-24": !compact })}>
      {!compact && (
        <>
          <h2 className="section-title text-center">Register Your Team</h2>
          <p className="section-subtitle mt-4 text-center">
            Complete the application below. You can save your progress and return later.
          </p>
        </>
      )}
      <form 
        className="mt-10 grid grid-cols-1 gap-8 text-left"
        onSubmit={(e) => {
          e.preventDefault();
        }}
      >
        <FormBlock title="Team Information">
          <Input label="Team Name" placeholder="e.g. Strategy Mavericks" />
        </FormBlock>

        <FormBlock title="Team Leader">
          <div className="grid gap-6 md:grid-cols-2">
            <Input label="Leader Name" placeholder="Full name" />
            <Input label="BRACU ID" placeholder="ID number" />
            <Input label="Email" placeholder="name@bracu.ac.bd" type="email" />
            <Input label="Phone Number" placeholder="+8801XXXXXXXXX" />
            <Input label="Department" placeholder="Department / Major" className="md:col-span-2" />
          </div>
        </FormBlock>

        <FormBlock title="Team Members">
          <div className="grid gap-6">
            {Array.from({ length: memberCount }).map((_, index) => {
              const optional = index >= 1;
              const suffix = optional ? " (Optional)" : "";
              return (
                <div
                  key={index}
                  className="rounded-3xl border border-auroraBlue/15 bg-transparent backdrop-blur-sm p-6 shadow-panel md:p-8"
                >
                  <p className="text-xs uppercase tracking-[0.3em] text-mist/60">
                    Member {index + 1}
                    {suffix}
                  </p>
                  <div className="mt-4 grid gap-6 md:grid-cols-2">
                    <Input
                      label={`Name${suffix}`}
                      placeholder="Full name"
                      className="md:col-span-2"
                    />
                    <Input label={`BRACU ID${suffix}`} placeholder="ID number" />
                    <Input
                      label={`Email${suffix}`}
                      placeholder="name@bracu.ac.bd"
                      type="email"
                    />
                    <Input
                      label={`Phone Number${suffix}`}
                      placeholder="+8801XXXXXXXXX"
                    />
                    <Input
                      label={`Department${suffix}`}
                      placeholder="Department / Major"
                      className="md:col-span-2"
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            {memberCount < 4 && (
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setMemberCount((count) => Math.min(count + 1, 4));
                }}
                className="outline-button px-6 py-2 text-xs"
              >
                Add Member
              </button>
            )}
            {memberCount > 1 && (
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setMemberCount((count) => Math.max(count - 1, 1));
                }}
                className="outline-button px-6 py-2 text-xs"
              >
                Remove Member
              </button>
            )}
            <p className="text-xs uppercase tracking-[0.25em] text-mist/45">
              Add up to 3 additional members (maximum 4 per team).
            </p>
          </div>
        </FormBlock>

        <FormBlock title="Payment Information">
          <div className="space-y-6">
            <div className="rounded-2xl border border-auroraBlue/20 bg-transparent backdrop-blur-sm p-4 md:p-6">
              <p className="text-xs md:text-sm text-mist/80 mb-4 leading-relaxed">
                Send Money <span className="font-semibold text-auroraBlue">600 BDT</span> to the following number via bKash or Nagad:
              </p>
              <div className="flex flex-col gap-2">
                <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                  <span className="text-[10px] sm:text-xs uppercase tracking-[0.25em] text-mist/60 whitespace-nowrap">Bkash/Nagad:</span>
                </div>
                <span className="font-display text-base sm:text-lg md:text-xl tracking-[0.1em] text-auroraBlue break-all">01822076101</span>
              </div>
            </div>

            <div>
              <label className="text-xs uppercase tracking-[0.25em] text-mist/60 mb-3 block">
                Payment Method <span className="text-auroraBlue">*</span>
              </label>
              <div className="flex gap-2 sm:gap-3">
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setPaymentMethod(() => "bkash");
                  }}
                  className={clsx(
                    "flex-1 rounded-2xl border px-2 sm:px-0 py-3 sm:py-4 text-[10px] sm:text-xs uppercase tracking-[0.2em] sm:tracking-[0.25em] transition font-semibold min-h-[44px]",
                    paymentMethod === "bkash"
                      ? "border-auroraBlue bg-auroraBlue/15 text-auroraBlue"
                      : "border-auroraBlue/20 bg-transparent text-mist/60 hover:text-mist"
                  )}
                >
                  bKash
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setPaymentMethod(() => "nagad");
                  }}
                  className={clsx(
                    "flex-1 rounded-2xl border px-2 sm:px-0 py-3 sm:py-4 text-[10px] sm:text-xs uppercase tracking-[0.2em] sm:tracking-[0.25em] transition font-semibold min-h-[44px]",
                    paymentMethod === "nagad"
                      ? "border-auroraBlue bg-auroraBlue/15 text-auroraBlue"
                      : "border-auroraBlue/20 bg-transparent text-mist/60 hover:text-mist"
                  )}
                >
                  Nagad
                </button>
              </div>
            </div>

            {paymentMethod === "bkash" && (
              <div key="bkash-details" className="rounded-2xl border border-auroraBlue/20 bg-transparent backdrop-blur-sm p-4 md:p-6 space-y-4 md:space-y-6">
                <h4 className="font-display text-base sm:text-lg uppercase tracking-[0.2em] text-mist">bKash Payment Details</h4>
                <Input
                  label="Phone Number Used for Payment *"
                  placeholder="01XXXXXXXXX"
                  type="tel"
                />
                <Input
                  label="Transaction ID *"
                  placeholder="Enter your bKash transaction ID"
                />
                <div>
                  <Input
                    label="Reference Note"
                    placeholder="Enter reference note for payment"
                  />
                  <p className="mt-2 text-[10px] sm:text-xs text-mist/50 italic leading-relaxed">
                    Reference will be cross checked, only if any problem occurs in payment process later on.
                  </p>
                </div>
              </div>
            )}

            {paymentMethod === "nagad" && (
              <div key="nagad-details" className="rounded-2xl border border-auroraBlue/20 bg-transparent backdrop-blur-sm p-4 md:p-6 space-y-4 md:space-y-6">
                <h4 className="font-display text-base sm:text-lg uppercase tracking-[0.2em] text-mist">Nagad Payment Details</h4>
                <Input
                  label="Phone Number Used for Payment *"
                  placeholder="01XXXXXXXXX"
                  type="tel"
                />
                <Input
                  label="Transaction ID *"
                  placeholder="Enter your Nagad transaction ID"
                />
                <div>
                  <Input
                    label="Reference Note"
                    placeholder="Enter reference note for payment"
                  />
                  <p className="mt-2 text-[10px] sm:text-xs text-mist/50 italic leading-relaxed">
                    Reference will be cross checked, only if any problem occurs in payment process later on.
                  </p>
                </div>
              </div>
            )}
          </div>
        </FormBlock>

        <div className="flex flex-col gap-4 md:flex-row md:justify-between md:gap-6">
          <div className="text-xs text-mist/60">
            <p>By submitting, you agree to the competition rules &amp; privacy policy.</p>
          </div>
          <div className="flex flex-col gap-3 md:flex-row">
            <button type="button" className="outline-button md:px-10">
              Save Draft
            </button>
            <button type="submit" className="primary-button md:px-12">
              Submit Registration
            </button>
          </div>
        </div>
      </form>
    </section>
  );
}

function FormBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="w-full rounded-3xl border border-auroraBlue/15 bg-transparent backdrop-blur-sm p-6 shadow-panel md:p-8">
      <h3 className="font-display text-2xl uppercase tracking-[0.2em] text-mist">{title}</h3>
      <div className="mt-6 space-y-6">{children}</div>
    </div>
  );
}

function Input({
  label,
  placeholder,
  type = "text",
  className
}: {
  label: string;
  placeholder: string;
  type?: string;
  className?: string;
}) {
  return (
    <div className={clsx("flex flex-col gap-2", className)}>
      <label className="text-xs uppercase tracking-[0.3em] text-mist/60">{label}</label>
      <input
        type={type}
        placeholder={placeholder}
        className="w-full rounded-2xl border border-auroraBlue/15 bg-transparent backdrop-blur-sm px-5 py-4 text-sm text-mist placeholder:text-mist/35 focus:border-auroraBlue focus:outline-none focus:ring-2 focus:ring-auroraBlue/40"
      />
    </div>
  );
}

