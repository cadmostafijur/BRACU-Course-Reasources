export default function MovingLightBackground() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-midnight via-transparent to-midnight opacity-70" />
      {/* <div className="moving-beam absolute left-1/2 top-1/2 h-[140%] w-[35%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle_at_center,_rgba(74,201,255,0.4)_0%,_rgba(42,246,193,0.2)_32%,_rgba(7,11,31,0)_72%)] blur-3xl" />
      <div className="moving-beam-delay absolute left-1/2 top-1/2 h-[160%] w-[20%] -translate-x-1/2 -translate-y-1/2 rotate-6 rounded-full bg-[linear-gradient(90deg,_rgba(74,155,255,0.18)_0%,_rgba(74,201,255,0.45)_35%,_rgba(42,246,193,0.28)_65%,_rgba(7,11,31,0)_100%)] blur-2xl" /> */}
      <div className="moving-beam absolute left-1/2 top-1/2 h-[140%] w-[35%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle_at_center,_rgba(255,255,255,0.45)_0%,_rgba(255,255,255,0.25)_32%,_rgba(7,11,31,0)_75%)] blur-3xl" />
      <div className="moving-beam-delay absolute left-1/2 top-1/2 h-[160%] w-[20%] -translate-x-1/2 -translate-y-1/2 rotate-6 rounded-full bg-[linear-gradient(90deg,_rgba(255,255,255,0.12)_0%,_rgba(255,255,255,0.5)_35%,_rgba(255,255,255,0.18)_65%,_rgba(7,11,31,0)_100%)] blur-2xl" />
    </div>
  );
}

